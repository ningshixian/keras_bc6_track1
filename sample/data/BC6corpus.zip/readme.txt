BC6 Bio-ID 语料说明


The tagger outputs the base forms, word, part-of-speech (POS) tags, chunk tags,
  and golden label in the following tab-separated format.

  word1	POStag1	chunktag1 Dictionarytag1 label1
  word2	POStag2	chunktag2 Dictionarytag2 label2
    :     :        :       :       :

  Chunks and Dictionary tag are represented in the IOB2 format (B for BEGIN,
  I for INSIDE, and O for OUTSIDE).